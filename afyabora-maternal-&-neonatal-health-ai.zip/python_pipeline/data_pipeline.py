"""
data_pipeline.py
================
Ingestion, cleaning, normalization, and anonymization pipeline for Kenyan health registers:
- MOH 405 (ANC Register)
- MOH 333 (Maternity Register)
- MOH 406 (Postnatal Care PNC Register)
- MOH 206 (PMTCT Longitudinal Exposed Infant Cohort)
"""

import pandas as pd
import numpy as np
import yaml
from pathlib import Path
from typing import Dict, Tuple, List, Optional

PROHIBITED_PII_PATTERNS = [
    'name', 'phone', 'tel', 'mobile', 'id_number', 'national_id',
    'huduma', 'address', 'village', 'estate', 'email'
]

def load_config(config_path: str = "config.yaml") -> Dict:
    with open(config_path, 'r') as f:
        return yaml.safe_load(f)

def sanitize_and_deidentify(df: pd.DataFrame) -> pd.DataFrame:
    """Removes any columns matching identifiable patient information (PII)."""
    cleaned_df = df.copy()
    cols_to_drop = [
        c for c in cleaned_df.columns
        if any(pii in c.lower() for pii in PROHIBITED_PII_PATTERNS)
    ]
    if cols_to_drop:
        cleaned_df = cleaned_df.drop(columns=cols_to_drop)
    return cleaned_df

def validate_and_clean_anc(df: pd.DataFrame) -> pd.DataFrame:
    """Cleans and validates MOH 405 ANC records."""
    df = sanitize_and_deidentify(df)
    
    # Blood pressure range sanitization
    if 'systolic_bp' in df.columns:
        df['systolic_bp'] = pd.to_numeric(df['systolic_bp'], errors='coerce')
        df.loc[(df['systolic_bp'] < 60) | (df['systolic_bp'] > 240), 'systolic_bp'] = np.nan
        
    if 'diastolic_bp' in df.columns:
        df['diastolic_bp'] = pd.to_numeric(df['diastolic_bp'], errors='coerce')
        df.loc[(df['diastolic_bp'] < 40) | (df['diastolic_bp'] > 160), 'diastolic_bp'] = np.nan
        
    if 'haemoglobin' in df.columns:
        df['haemoglobin'] = pd.to_numeric(df['haemoglobin'], errors='coerce')
        df.loc[(df['haemoglobin'] < 3.0) | (df['haemoglobin'] > 20.0), 'haemoglobin'] = np.nan
        
    if 'total_anc_visits' in df.columns:
        df['total_anc_visits'] = pd.to_numeric(df['total_anc_visits'], errors='coerce').fillna(1).astype(int)
        
    return df

def integrate_longitudinal_registers(
    anc_df: pd.DataFrame,
    mat_df: pd.DataFrame,
    pnc_df: pd.DataFrame,
    pmtct_df: pd.DataFrame
) -> pd.DataFrame:
    """
    Integrates ANC, Maternity, PNC, and MOH 206 using consistent pseudonymous mother IDs.
    Prevents data leakage by tracking visit timestamps appropriately.
    """
    anc_clean = validate_and_clean_anc(anc_df)
    mat_clean = sanitize_and_deidentify(mat_df)
    pnc_clean = sanitize_and_deidentify(pnc_df)
    pmtct_clean = sanitize_and_deidentify(pmtct_df)

    merged = anc_clean.merge(
        mat_clean[['mother_pseudonym', 'delivery_mode', 'maternal_complications', 'birth_weight_kg', 'apgar_score_5min']],
        on='mother_pseudonym',
        how='left'
    )

    merged = merged.merge(
        pnc_clean[['mother_pseudonym', 'pnc_visit_time', 'maternal_survival', 'child_survival']],
        on='mother_pseudonym',
        how='left'
    )

    merged = merged.merge(
        pmtct_clean[['mother_pseudonym', 'baseline_hiv_status', 'seroconversion_status', 'five_year_child_hiv_status', 'viral_suppression_category']],
        on='mother_pseudonym',
        how='left'
    )

    return merged

def apply_small_cell_suppression(series: pd.Series, threshold: int = 5) -> pd.Series:
    """Suppresses cell counts less than threshold to prevent re-identification."""
    return series.apply(lambda x: "<5" if (pd.notnull(x) and 0 < x < threshold) else str(x))
