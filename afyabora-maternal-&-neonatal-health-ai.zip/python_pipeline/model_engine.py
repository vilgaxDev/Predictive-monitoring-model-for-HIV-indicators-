"""
model_engine.py
===============
Machine learning model training, cross-validation, and clinical risk evaluation
for Kenyan maternal & neonatal outcomes.
"""

import numpy as np
import pandas as pd
from typing import Dict, Tuple, Any
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score, confusion_matrix
from sklearn.calibration import calibration_curve

FEATURE_COLUMNS = [
    'maternal_age', 'gravida', 'parity', 'gestational_age_weeks',
    'total_anc_visits', 'systolic_bp', 'diastolic_bp', 'haemoglobin',
    'blood_glucose', 'proteinuria_num', 'hiv_positive_flag',
    'arv_non_adherent_flag', 'diabetes_flag'
]

def engineer_features(df: pd.DataFrame) -> Tuple[pd.DataFrame, pd.Series]:
    """Encodes clinical features into numeric vectors for modeling."""
    X = pd.DataFrame()
    X['maternal_age'] = df['maternal_age'].fillna(25)
    X['gravida'] = df['gravida'].fillna(1)
    X['parity'] = df['parity'].fillna(0)
    X['gestational_age_weeks'] = df['gestational_age_weeks'].fillna(28)
    X['total_anc_visits'] = df['total_anc_visits'].fillna(1)
    X['systolic_bp'] = df['systolic_bp'].fillna(118)
    X['diastolic_bp'] = df['diastolic_bp'].fillna(76)
    X['haemoglobin'] = df['haemoglobin'].fillna(11.5)
    X['blood_glucose'] = df['blood_glucose'].fillna(5.2)

    # Ordinal proteinuria mapping
    prot_map = {'Negative': 0, 'Trace': 0.5, '1+': 1, '2+': 2, '3+': 3}
    X['proteinuria_num'] = df['proteinuria'].map(prot_map).fillna(0)

    # HIV and adherence flags
    X['hiv_positive_flag'] = df['hiv_status'].isin(['Positive', 'Seroconverted']).astype(int)
    X['arv_non_adherent_flag'] = (df['arv_adherence'] == 'Poor').astype(int)
    X['diabetes_flag'] = df['diabetes_status'].isin(['Gestational DM', 'Pre-existing DM']).astype(int)

    # Target label: adverse maternal-neonatal outcome
    # Defined by pre-eclampsia, eclampsia, hemorrhage, or severe neonatal distress
    y = df['maternal_complications'].apply(
        lambda x: 1 if isinstance(x, list) and any(c in ['Pre-eclampsia', 'Eclampsia', 'Postpartum Haemorrhage (PPH)'] for c in x)
        else (1 if isinstance(x, str) and ('Pre-eclampsia' in x or 'Eclampsia' in x or 'PPH' in x) else 0)
    )

    return X, y

def train_and_evaluate_model(
    df: pd.DataFrame,
    test_size: float = 0.25,
    random_state: int = 42
) -> Dict[str, Any]:
    """Trains a Gradient Boosting model with evaluation metrics and calibration."""
    X, y = engineer_features(df)
    
    # Train/Test split to avoid data leakage
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=test_size, random_state=random_state, stratify=y if y.nunique() > 1 else None
    )

    # Fit Gradient Boosting model
    model = GradientBoostingClassifier(
        n_estimators=120,
        learning_rate=0.08,
        max_depth=4,
        random_state=random_state
    )
    model.fit(X_train, y_train)

    y_pred = model.predict(X_test)
    y_prob = model.predict_proba(X_test)[:, 1] if hasattr(model, 'predict_proba') else y_pred

    acc = accuracy_score(y_test, y_pred)
    prec = precision_score(y_test, y_pred, zero_division=0)
    rec = recall_score(y_test, y_pred, zero_division=0)
    f1 = f1_score(y_test, y_pred, zero_division=0)
    roc = roc_auc_score(y_test, y_prob) if y_test.nunique() > 1 else 0.5
    cm = confusion_matrix(y_test, y_pred)

    prob_true, prob_pred = calibration_curve(y_test, y_prob, n_bins=10)

    return {
        'model': model,
        'feature_names': list(X.columns),
        'metrics': {
            'accuracy': float(acc),
            'precision': float(prec),
            'recall': float(rec),
            'f1_score': float(f1),
            'roc_auc': float(roc)
        },
        'confusion_matrix': cm.tolist(),
        'calibration': {
            'prob_pred': prob_pred.tolist(),
            'prob_true': prob_true.tolist()
        },
        'X_train': X_train,
        'X_test': X_test,
        'y_test': y_test
    }
