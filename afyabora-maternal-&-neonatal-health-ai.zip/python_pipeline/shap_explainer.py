"""
shap_explainer.py
=================
Explainable AI engine using SHAP (SHapley Additive exPlanations) for maternal risk models.
Distinguishes statistical associations from clinical causal effects.
"""

import numpy as np
import pandas as pd
import shap
from typing import Dict, Any, List

def compute_shap_explanations(model: Any, X_sample: pd.DataFrame) -> Dict[str, Any]:
    """Computes TreeSHAP explanations for tree-based ensemble models."""
    explainer = shap.TreeExplainer(model)
    shap_values = explainer.shap_values(X_sample)

    # In binary classification, take positive class Shapley values if list
    if isinstance(shap_values, list):
        shap_matrix = shap_values[1]
    else:
        shap_matrix = shap_values

    # Mean absolute SHAP across population
    mean_abs_shap = np.mean(np.abs(shap_matrix), axis=0)
    features = list(X_sample.columns)

    feature_importance = [
        {'feature': feat, 'importance': float(score)}
        for feat, score in sorted(zip(features, mean_abs_shap), key=lambda x: x[1], reverse=True)
    ]

    return {
        'explainer': explainer,
        'shap_matrix': shap_matrix,
        'expected_value': float(explainer.expected_value[1] if isinstance(explainer.expected_value, (list, np.ndarray)) else explainer.expected_value),
        'feature_importance': feature_importance
    }

def explain_single_patient(
    explainer: Any,
    patient_row: pd.DataFrame,
    feature_names: List[str]
) -> List[Dict[str, Any]]:
    """Explains an individual patient's prediction using additive Shapley attributions."""
    shap_vals = explainer.shap_values(patient_row)
    if isinstance(shap_vals, list):
        patient_shap = shap_vals[1][0]
    else:
        patient_shap = shap_vals[0]

    explanations = []
    for feat, impact in zip(feature_names, patient_shap):
        val = patient_row[feat].values[0]
        explanations.append({
            'feature': feat,
            'impact': float(impact),
            'value': float(val) if isinstance(val, (int, float, np.number)) else str(val)
        })

    # Sort by absolute impact
    explanations.sort(key=lambda x: abs(x['impact']), reverse=True)
    return explanations
